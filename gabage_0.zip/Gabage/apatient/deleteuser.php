<?php 
  include 'connect.php';
    
$id=$_GET['id'];
$delete=mysqli_query($con,"delete from admin where id='$id'");
if ($delete) {
	header("location:users1.php");
   echo "deleted";
}
else{
 echo "not deleted".mysqli_error();

}

 ?>