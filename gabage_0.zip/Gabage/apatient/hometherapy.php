<?php include 'head.php'; 
        
include 'aside.php'; ?>

    
        <div class="page-wrapper">
      
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Home Therapy</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="index.php" class="text-muted">Home</a></li>
                                    <li class="breadcrumb-item"><a href="hometherapy.php" class="text-muted">Request Therapy</a></li>
                                    <li class="breadcrumb-item"><a href="hometherapy2.php" class="text-muted">Pending Therapy Approval</a></li>
                                    
                                    <li class="breadcrumb-item"><a href="hometherapy3.php" class="text-muted">Approved Therapy Equipments</a></li>
                                    <li class="breadcrumb-item"><a href="hometherapy4.php" class="text-muted">Therapy Results</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-5 align-self-center">
                        <div class="customize-input float-right">
                            <h4><?php echo date('Y-m-d'); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
       
           <div class="container-fluid">
               
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                          <form  enctype="multipart/form-data" method="post" action="" autocomplete="off">
                             <input type="hidden" required  name="fileNo" class="form-input" aria-required="true"  value="">

                               

                         <input type="hidden" name="date" required  class="form-control" value="<?php echo date('Y-m-d h:i:s A') ?>">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                            <label>Patient Names</label>
                                                </div>
                                            </div>

           <div class="col-md-10">
                            <div class="form-group">
                         	
         <input type="text" name="patientname" required class="form-control" placeholder="Enter the name of the patient you are registering">
                                                </div>
                                            </div>
                                        </div>


                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Category</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
    <select name="category" class="form-control show-tick" required data-live-search="true">
                                      <option selected value="">Choose Therapy Category</option>
                     <?php 
                     $x=mysqli_query($con,"SELECT * FROM therapycategory");
                     while($v=mysqli_fetch_array($x))
                     {
                     ?>
                     <option value="<?php echo $v['therapycategoryname'];?>">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $v['therapycategoryname'];?></option> 
                     <?php } ?>
                                    </select>
                                  <input type="hidden" name="regDate" required  class="form-control" value="<?php echo date('Y-m-d h:i:s A') ?>">

                                                </div>
                                            </div>
                                        </div>



                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Gender</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
                                                     <select name="gender" class="form-control show-tick" required data-live-search="true">
                                      <option selected value="">Choose Gender </option>
                                       
                                       <option value="Male"> Male</option> 
                                       <option value="Female">Female </option> 
                                       

                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        
 <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Weight</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                <div class="form-group">
            <input type="number" name="weight" required class="form-control" placeholder="Enter the weight of the patient you are registering">
                                                </div>
                                            </div>
                                        </div>
                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Age</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
          <input type="number" name="ageBrac" required class="form-control" placeholder="Enter the age of the patient you are registering">
                                                </div>
                                            </div>
                                        </div>



                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Address</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
          <input type="text" name="address" required class="form-control" placeholder="Enter the address of the user you are registering">
       <input type="hidden" name="user" required  class="form-control" value="<?php echo $_SESSION['username'];?>">

                          <input type="hidden" required  name="paystatus" class="form-input" aria-required="true"  value="pending">
                           <input type="hidden" required  name="assistant" class="form-input" aria-required="true"  value="pending">
                                             
                                                </div>
                                            </div>
                                        </div>




                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                 <label>Payment Category</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
              <select name="paymentcat" class="form-control show-tick" required data-live-search="true">
                                      <option selected value="">---Choose---</option>
                                       <option value="Mobile Money">&nbsp;&nbsp;&nbsp;&nbsp;Mobile Money</option>
                                        <option value="Visa Card">&nbsp;&nbsp;&nbsp;&nbsp;Visa Card</option> 
                                      </select>
                                                </div>
                                            </div>
                                        </div>





                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                         <label>Primary Doctor</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                            	    <?php 
  $sql=mysqli_query($con,"SELECT primary_doc FROM userprofile WHERE username='$a'");
                                      while($row=mysqli_fetch_array($sql))
                                      {
                                      ?>
                                                <div class="form-group">
               <input name="doctor" type="text" readonly class="form-control"  value="<?php echo $row['primary_doc'];?>">
                                       <?php } ?>
                                                </div>



                           
                                            </div>
                                        </div>


                                        
                                       
                                        
                                    
                                    </div>
                                    <div class="form-actions">
                                        <div class="text-right">
                                            <button type="submit"  name="submit" class="btn btn-info">REQUEST THERAPY</button>
                                            <button type="reset" class="btn btn-dark">Reset</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>




<?php


    if (isset($_POST['submit'])) {
        $fileNo=$_POST['fileNo'];
    $pass=$_POST['patientname'];
    $fname=$_POST['gender'];
    $fon=$_POST['ageBrac'];
    $email=$_POST['weight'];
    $address=$_POST['paymentcat'];
    $add=$_POST['date'];
    $district=$_POST['doctor'];
    $village=$_POST['user'];
    $category=$_POST['category'];
    $paystatus=$_POST['paystatus'];
    $paystatu=$_POST['address'];
    $assistant=$_POST['assistant'];
   
     
    
  

$query=mysqli_query($con,"INSERT INTO hometherapy (fileNo,patientname,gender,ageBrac,weight,paymentcat,date,doctor,user,category,paystatus,address,assistant) VALUES('$fileNo','$pass','$fname','$fon','$email','$address','$add','$district','$village','$category','$paystatus','$paystatu','$assistant')");

        if ($query) {
            echo "successfull";
            header("Location: hometherapy2.php");
        }else{
            echo "error occurred";
        }
    
    
}

     ?>










              
                
             
       
              
<?php include 'footer.php'; ?>