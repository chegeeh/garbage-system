<?php include 'head.php'; 
        
include 'aside.php'; ?>

    
        <div class="page-wrapper">
      
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Home Therapy</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="index.php" class="text-muted">Home</a></li>
                                    <li class="breadcrumb-item"><a href="hometherapy.php" class="text-muted">Request Therapy</a></li>
                                    <li class="breadcrumb-item"><a href="hometherapy2.php" class="text-muted">Pending Therapy Approval</a></li>
                                    
                                    <li class="breadcrumb-item"><a href="hometherapy3.php" class="text-muted">Approved Therapy Equipments</a></li>
                                    <li class="breadcrumb-item"><a href="hometherapy4.php" class="text-muted">Therapy Results</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-5 align-self-center">
                        <div class="customize-input float-right">
                            <h4><?php echo date('Y-m-d'); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
       
                             



       
       
            <div class="container-fluid">
               
                <div class="row">

                   
  <?php 
         $sq=mysqli_query($con,"SELECT * FROM hometherapy WHERE assistant='pending' AND user='$a'");
                            ?>


                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                            </div>
                           <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">File No</th>
                                        <th scope="col">Patient Names</th>
                                        
                                     
                                        <th scope="col">Payment Category</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Provider</th>
                                        <th scope="col">Username</th>
                                        <th scope="col">Therapy Category</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Address</th>
                                    </tr>
                                </thead>


                                <?php $k=1;
                                    while($hk=mysqli_fetch_array($sq))
                                    { ?>
                                <tbody>
                                    <tr>
                                        <th scope="row"><?php echo $k;?></th>
                                            <td><?php echo ucfirst($hk['fileNo']);?></td>
                                            <td><?php echo ucfirst($hk['patientname']);?></td>

                                          
                                           
                                            <td><?php echo ucfirst($hk['paymentcat']);?></td>
                                            <td><?php echo ucfirst($hk['date']);?></td>
                                            <td><?php echo ucfirst($hk['doctor']);?></td>

                                            <td><?php echo ucfirst($hk['user']);?></td>
                                            <td><?php echo ucfirst($hk['category']);?></td>
                                            <td><?php echo ucfirst($hk['paystatus']);?></td>
                                            <td><?php echo ucfirst($hk['address']);?></td>
                                           
                                    </tr>
                                  <?php $k++; } ?>
                                </tbody>
                            </table>

                        </div>
                    </div>








                
                    
                </div>
                
            <?php include 'footer.php'; ?>