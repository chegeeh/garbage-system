<?php include 'head.php'; 
        
include 'aside.php'; ?>

    
        <div class="page-wrapper">
      
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Register A Patient</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                   
                                    <li class="breadcrumb-item"><a href="hire.php?user=<?php echo $_SESSION['username']; ?>" class="text-muted">Request Ambulance</a></li>
                                     <li class="breadcrumb-item"><a href="hire3.php?user=<?php echo $_SESSION['username']; ?>" class="text-muted">View Ambulance Requests</a></li>
                                    <li class="breadcrumb-item"><a href="hire2.php?user=<?php echo $_SESSION['username']; ?>" class="text-muted">Approved Ambulance Requests</a></li>
                                    
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-5 align-self-center">
                        <div class="customize-input float-right">
                            <h4><?php echo date('Y-m-d'); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
       
           <div class="container-fluid">
               
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                          <form  enctype="multipart/form-data" method="post" action="" autocomplete="off">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                            <label>Short Details</label>
                                                </div>
                                            </div>

           <div class="col-md-10">
                            <div class="form-group">
                         <input type="hidden" name="date" required  class="form-control" value="<?php echo date('Y-m-d') ?>">

                                     <input type="hidden" name="user" value="<?php echo $_SESSION['username'] ?>" required="required">
                                     <input type="hidden" name="labstatus1" value="pending" required="required">

                                     <input type="hidden" name="accountantstatus" value="pending" required="required">
                                      <input type="hidden" name="paycategory" value="pending" required="required">
                                     <input type="hidden" name="paystatus" value="pending" required="required">

                                     
                                     <input type="hidden" name="type" value="Emergency" required="required">
                                        <input type="hidden" name="amount" value="0" required="required">
                                  
                                     <input type="hidden" name="ambuname" value="pending" required="required">
                                     <input type="hidden" name="status" value="pending" required="required">                                    
         <input type="text" name="details" required class="form-control" placeholder="Enter the short detail conditions of the patient you are registering">
                                                </div>
                                            </div>
                                        </div>
                                         <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label>Address</label>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
           <input type="text" name="route" id="text" required  class="form-control" placeholder="Enter Address" >

                                                </div>
                                            </div>
                                        </div>
                                         


                                        
                                       
                                        
                                    
                                    </div>
                                    <div class="form-actions">
                                        <div class="text-right">
                                            <button type="submit"  name="submit" class="btn btn-info">REGISTER PATIENT</button>
                                            <button type="reset" class="btn btn-dark">Reset</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>




<?php


   
   
    if (isset($_POST['submit'])) {
      







      $date=$_POST['date'];
    $details=$_POST['details'];
    $user=$_POST['user'];
    $route=$_POST['route'];
    $labstatus1=$_POST['labstatus1'];
    $accountantstatus=$_POST['accountantstatus'];
    $paycategory=$_POST['paycategory'];
    $paystatus=$_POST['paystatus'];
    $ambuname=$_POST['ambuname'];
    
    $type=$_POST['type'];

    $status=$_POST['status'];
    $amount=$_POST['amount'];
    
  

$query=mysqli_query($con,"INSERT INTO addambulance (date,details,user,route,labstatus1,accountantstatus,paycategory,paystatus,ambuname,type,status,amount) VALUES('$date','$details','$user','$route','$labstatus1','$accountantstatus','$paycategory','$paystatus','$ambuname','$type','$status','$amount')");

        if ($query) {
            echo "successfull";
            header("Location: hire3.php");
        }else{
            echo "error occurred";
        }
    
    
}

     ?>










              
                
             
       
              
          <?php include 'footer.php'; ?>