<?php include 'head.php'; 
        
include 'aside.php'; ?>

    
        <div class="page-wrapper">
      
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1"> Ambulance</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="index.php" class="text-muted">Home</a></li>
                                  <li class="breadcrumb-item"><a href="hire.php?user=<?php echo $_SESSION['username']; ?>" class="text-muted">Request Ambulance</a></li>
                                     <li class="breadcrumb-item"><a href="hire3.php?user=<?php echo $_SESSION['username']; ?>" class="text-muted">View Ambulance Requests</a></li>
                                    <li class="breadcrumb-item"><a href="hire2.php?user=<?php echo $_SESSION['username']; ?>" class="text-muted">Approved Ambulance Requests</a></li>
                                    
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-5 align-self-center">
                        <div class="customize-input float-right">
                            <h4><?php echo date('Y-m-d'); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
       
                             



       
       
            <div class="container-fluid">
               
                <div class="row">

                   
 <?php 
						$a=$_SESSION['username'];
                           
                       $sq=mysqli_query($con,"SELECT * FROM addambulance WHERE user='$a' AND status='Approved' ");
							?>


                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title"></h4>
                            </div>
                           <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Date</th>
                                            <th scope="col">Details</th>
                                            <th scope="col">Username</th>
                                            <th scope="col">Route</th>
                                            <th scope="col">Ambulance Driver</th> 
                                            <th scope="col"> Reviewed By</th>
                                             <th scope="col">Payment Status</th>
                                         <th scope="col">Ambulance</th>
                                         <th scope="col">Type</th>
                                          <th scope="col">Status</th>

                                    </tr>
                                </thead>


                                <?php $k=1;
									while($hk=mysqli_fetch_array($sq))
									{ ?>
                                <tbody>
                                    <tr>
                                        <th scope="row"><?php echo $k;?></th>
                                          <td><?php echo $hk['date'];?></td>                                      
                                     <td><?php echo $hk['details'];?></td>
                                            <td><?php echo $hk['user'];?></td>
                                            <td><?php echo $hk['route'];?></td>
                                            <td><?php echo $hk['labstatus1'];?></td>
                                            <td><?php echo $hk['accountantstatus'];?></td>
                                             <td><?php echo $hk['paystatus'];?></td>
                                            <td><?php echo $hk['ambuname'];?></td>
                                            <td><?php echo $hk['type'];?></td>
                                            <td><?php echo $hk['status'];?></td>
                                    </tr>
                                  <?php $k++; } ?>
                                </tbody>
                            </table>

                        </div>
                    </div>








                
                    
                </div>
                
            <?php include 'footer.php'; ?>