<?php
session_start();
include('connect.php');

    if (isset($_POST['submit'])) {
$username = $_POST['username'];
$amount = $_POST['amount'];
$phone_number = $_POST['phone_number'];
$address = $_POST['address'];
$status = $_POST['status'];
$email = $_POST['email'];
 $date = $_POST['date'];
 $reason = $_POST['reason'];

 
$query=mysqli_query($con,"INSERT INTO consult (username,amount,phone_number,address,status,email,date,reason) VALUES('$username','$amount','$phone_number','$address','$status','$email','$date','$reason')");

        if ($query) {
            echo "successfull";
            header("Location: cash7.php?username=$username&amount=$amount&phone_number=$phone_number&address=$address&status=$status&email=$email&date=$date&reason=$reason");
        }else{
            echo "error occurred";
        }
    
    }


   


// query



?>